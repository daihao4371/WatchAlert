use watchalert;
INSERT  ignore INTO `tenants` (`id`, `name`, `create_at`, `create_by`, `manager`, `description`, `user_number`, `rule_number`, `duty_number`, `notice_number`, `remove_protection`) VALUES ('default', 'default', 1711876400, 'system', 'admin', 'default 租户', 999, 999, 999, 999, 1);

