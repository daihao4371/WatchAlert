use watchalert;
INSERT  ignore INTO `tenant_linked_users`(`id`, `users`) VALUES ('default', '[{"userId":"admin","userName":"admin","userRole":"admin"}]');